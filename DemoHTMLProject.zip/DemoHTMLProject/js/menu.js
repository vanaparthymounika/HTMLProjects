function veg()
	{
		
		alert('You are selecting VegBiryani');
	}
	function Chicken()
	{
		
		alert('You are selecting ChickenBiryani');
	}
	function Mutton()
	{
		
		alert('You are selecting MuttonBiryani');
	}
	function prawn()
	{
		
		alert('You are selecting prawnsBiryani');
	}
	function Order() {
		
		
		
			alert('Thank You for ordering, You are redirecting to Address Details page');
			 window.location = "address.html";
       
	}